package com.example.myapplication1;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.res.Resources;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import android.view.ViewGroup.LayoutParams;



public class MainActivity extends AppCompatActivity {
    final Context context = this;
    private Button button;

    Spinner spinnerLanguage;
    TextView resultNameText,resultTextText,btnChangeTextText,spinnerNameText,numberChainsetText,numberCasetteText,lengthBracketHubText, alertDialogText;
    ArrayAdapter<String> mAdapter;
    ImageButton infoButtonChainset, infoButtonSuportHub,infoButtonCasette;

    CharSequence numberChainsetString, numberCasetteString, lengthBracketHubString, resultTextString;
    int initialResult=0;
    int numberChainringsLargestDiscChainset;    // Liczba zebow na najwiekszej tarczy korby
    int numberChainringsLargestDiscCasette;     // Liczba zebow na najwiekszej tarczy kasety
    int lengthBottomBracketRearHub;             // Odleglosc od srodka suportu do srodka tylnej piasty
    double constNumber=0.635;                   // Stala
    int functionTempA;                          // Funkcja przeliczajaca posrednia
    double functionTempB;                       // Funkcja przeliczajaca posrednia
    int functionTempC;                          // Funkcja przeliczajaca posrednia
    int functionTempD;                          // Funkcja przeliczajaca posrednia
    int functionTempE;                          // Funkcja przeliczajaca posrednia
    int functionCalculated;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final TextView numberChainset = (TextView) findViewById(R.id.numberChainset); //get the id for TextView
        final TextView numberCasette = (TextView) findViewById(R.id.numberCasette); //get the id for TextView
        final TextView lengthBracketHub = (TextView) findViewById(R.id.lengthBracketHub); //get the id for TextView
        final TextView resultText = (TextView) findViewById(R.id.resultText); //get the id for TextView

        resultTextString = String.valueOf(initialResult);
        Button changeText = (Button) findViewById(R.id.btnChangeText); //get the id for button

        spinnerLanguage = (Spinner) findViewById(R.id.spinner);
        numberChainsetText = (TextView) findViewById(R.id.numberChainset);
        numberCasetteText = (TextView) findViewById(R.id.numberCasette);
        lengthBracketHubText = (TextView) findViewById(R.id.lengthBracketHub);
        resultNameText = (TextView) findViewById(R.id.resultName);
        resultTextText = (TextView) findViewById(R.id.resultText);
        btnChangeTextText = (TextView) findViewById(R.id.btnChangeText);
        spinnerNameText = (TextView) findViewById(R.id.spinnerName);
        mAdapter = new ArrayAdapter<String>(MainActivity.this, android.R.layout.simple_spinner_dropdown_item, getResources().getStringArray(R.array.language_option));
        spinnerLanguage.setAdapter(mAdapter);

        if (LocaleHelper.getLanguage(MainActivity.this).equalsIgnoreCase("en")) {
            spinnerLanguage.setSelection(mAdapter.getPosition("English"));
        } else if (LocaleHelper.getLanguage(MainActivity.this).equalsIgnoreCase("pl")) {
            spinnerLanguage.setSelection(mAdapter.getPosition("Polski"));
        }

        spinnerLanguage.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                Context context;
                Resources resources;
                switch (i) {
                    case 0:
                        context = LocaleHelper.setLocale(MainActivity.this, "en");
                        resources = context.getResources();
                        numberChainsetText.setHint(resources.getString(R.string.napisKorba));
                        numberCasetteText.setHint(resources.getString(R.string.napisKaseta));
                        lengthBracketHubText.setHint(resources.getString(R.string.napisSuportPiasta));
                        resultNameText.setText(resources.getString(R.string.napisWynik));
                        resultTextText.setText(resources.getString(R.string.napisWynikRownania));
                        btnChangeTextText.setText(resources.getString(R.string.przyciskOblicz));
                        spinnerNameText.setText(resources.getString(R.string.napisTlumacz));

                        numberChainsetText.setOnFocusChangeListener(new View.OnFocusChangeListener() {
                            @Override
                            public void onFocusChange(View view, boolean hasFocus) {
                                if (hasFocus) {
                                    numberChainsetText.setHint("");
                                } else {
                                    numberChainsetText.setHint("Largest Chainset Disc Chainrings Number");
                                }
                            }
                        });
                        numberCasetteText.setOnFocusChangeListener(new View.OnFocusChangeListener() {
                            @Override
                            public void onFocusChange(View view, boolean hasFocus) {
                                if (hasFocus) {
                                    numberCasetteText.setHint("");
                                } else {
                                    numberCasetteText.setHint("Largest Casette Disc Chainrings Number");
                                }
                            }
                        });
                        lengthBracketHubText.setOnFocusChangeListener(new View.OnFocusChangeListener() {
                            @Override
                            public void onFocusChange(View view, boolean hasFocus) {
                                if (hasFocus) {
                                    lengthBracketHubText.setHint(" ");
                                } else {
                                    lengthBracketHubText.setHint("Bottom Bracket To Rear Hub Length [cm]");
                                }
                            }
                        });
                        break;
                    case 1:
                        context = LocaleHelper.setLocale(MainActivity.this, "pl");
                        resources = context.getResources();
                        numberChainsetText.setHint(resources.getString(R.string.napisKorba));
                        numberCasetteText.setHint(resources.getString(R.string.napisKaseta));
                        lengthBracketHubText.setHint(resources.getString(R.string.napisSuportPiasta));
                        resultNameText.setText(resources.getString(R.string.napisWynik));
                        resultTextText.setText(resources.getString(R.string.napisWynikRownania));
                        btnChangeTextText.setText(resources.getString(R.string.przyciskOblicz));
                        spinnerNameText.setText(resources.getString(R.string.napisTlumacz));
                          numberChainsetText.setOnFocusChangeListener(new View.OnFocusChangeListener() {
                          @Override
                            public void onFocusChange(View view, boolean hasFocus) {
                                if (hasFocus) {
                                    numberChainsetText.setHint("");
                                } else {
                                    numberChainsetText.setHint("Ilosc zebow najwiekszej tarczy korby");
                                }
                            }
                        });
                        numberCasetteText.setOnFocusChangeListener(new View.OnFocusChangeListener() {
                            @Override
                            public void onFocusChange(View view, boolean hasFocus) {
                                if (hasFocus) {
                                    numberCasetteText.setHint("");
                                } else {
                                    numberCasetteText.setHint("Ilosc zebow najwiekszej tarczy kasety");
                                }
                            }
                        });
                        lengthBracketHubText.setOnFocusChangeListener(new View.OnFocusChangeListener() {
                            @Override
                            public void onFocusChange(View view, boolean hasFocus) {
                                if (hasFocus) {
                                    lengthBracketHubText.setHint("");
                                } else {
                                    lengthBracketHubText.setHint("Odl. suport - tylna piasta [cm]");
                                }
                            }
                        });
                        break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        infoButtonChainset =(ImageButton)findViewById(R.id.infoButtonChainset);
        infoButtonChainset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // custom dialog
                final Dialog dialog = new Dialog(context);
                dialog.setContentView(R.layout.chainset_popup);
                ImageButton dialogButton = (ImageButton) dialog.findViewById(R.id.imageButton);
                // if button is clicked, close the custom dialog
                dialogButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                    }
                });
                dialog.show();
            }
        });
        infoButtonCasette =(ImageButton)findViewById(R.id.infoButtonCasette);
        infoButtonCasette.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // custom dialog
                final Dialog dialog = new Dialog(context);
                dialog.setContentView(R.layout.casette_popup);
                ImageButton dialogButton = (ImageButton) dialog.findViewById(R.id.imageButton);
                // if button is clicked, close the custom dialog
                dialogButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                    }
                });
                dialog.show();
            }
        });
        infoButtonSuportHub =(ImageButton)findViewById(R.id.infoButtonSuportHub);
        infoButtonSuportHub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // custom dialog
                final Dialog dialog = new Dialog(context);
                dialog.setContentView(R.layout.suport_hub_popup);
                ImageButton dialogButton = (ImageButton) dialog.findViewById(R.id.imageButton);
                // if button is clicked, close the custom dialog
                dialogButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                    }
                });
                dialog.show();
            }
        });

        changeText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                // Liczba zebow na najwiekszej tarczy korby
                numberChainsetString = numberChainset.getText();
                int numberChainringsLargestDiscChainset = Integer.parseInt(numberChainsetString.toString()); // String->Int

                // Liczba zebow na najwiekszej tarczy kasety
                numberCasetteString = numberCasette.getText();
                int numberChainringsLargestDiscCasette = Integer.parseInt(numberCasetteString.toString()); // String->Int

                // Odleglosc od srodka suportu do srodka tylnej piasty
                lengthBracketHubString = lengthBracketHub.getText();
                int lengthBottomBracketRearHub = Integer.parseInt(lengthBracketHubString.toString()); // String->Int
                if(numberChainringsLargestDiscChainset>0&&numberChainringsLargestDiscCasette>0&&lengthBottomBracketRearHub>0) {
                // Funkcje przeliczajace posrednie
                functionTempA = (numberChainringsLargestDiscChainset + numberChainringsLargestDiscCasette) / 2;
                functionTempB = lengthBottomBracketRearHub / constNumber;
                functionTempB = Math.round(functionTempB);
                functionTempC = (int) functionTempB;
                functionTempD = functionTempA + functionTempC + 2;
                if (functionTempD % 2 == 0) {
                    functionTempE = functionTempD;
                } else {
                    functionTempE = functionTempD + 1;
                }
                // Wynik
                functionCalculated = functionTempE;
                resultTextString = String.valueOf(functionCalculated); // Int->String

                // Wyswietlenie wyniku
                resultText.setText(resultTextString);
            }
            else{
                    alertDialogText = (TextView) findViewById(R.id.textAlert);
                    // add  listener
                    alertDialogText.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View arg0) {
                            // custom dialog
                            final Dialog dialog = new Dialog(context);
                            dialog.setContentView(R.layout.alert_inputs);
                            TextView textAlertDialog = (TextView) dialog.findViewById(R.id.textAlert);
                            // if button is clicked, close the custom dialog
                            textAlertDialog.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    dialog.dismiss();
                                }
                            });
                            dialog.show();
                        }
                    });
                }
            }
        });


    }

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(LocaleHelper.onAttach(base));
    }
}
